package com.example.practica5;

import javafx.animation.PauseTransition;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.effect.DropShadow;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.util.Duration;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

public class HelloController {

    private final Shobu juego = new Shobu();
    private final Map<Shobu.Pos, Button> botones = new HashMap<>();

    private Shobu.Pos seleccionada = null;
    private List<Shobu.Pos> destinosValidos = Collections.emptyList();

    private Label lblEstado;
    private ComboBox<String> cmbModo;

    public Parent crearInterfaz() {
        BorderPane root = new BorderPane();
        root.setPadding(new Insets(15));
        root.setStyle("-fx-background-color: #2c2f33;");

        Label lblModo = new Label("Modo:");
        lblModo.setTextFill(Color.LIGHTGRAY);
        lblModo.setFont(Font.font("System", FontWeight.BOLD, 13));

        cmbModo = new ComboBox<>();
        cmbModo.getItems().addAll("Jugador vs Jugador", "Jugador vs Máquina");
        cmbModo.setValue("Jugador vs Jugador");

        Button btnReiniciar = new Button("Nueva Partida");
        btnReiniciar.setStyle("-fx-background-color: #5865F2; -fx-text-fill: white; -fx-font-weight: bold;");

        // LAMBDA: Eventos para reiniciar o cambiar modo de juego
        btnReiniciar.setOnAction(e -> reiniciar());
        cmbModo.setOnAction(e -> reiniciar());

        lblEstado = new Label();
        lblEstado.setFont(Font.font("System", FontWeight.BOLD, 15));

        HBox barraSuperior = new HBox(12, lblModo, cmbModo, btnReiniciar, lblEstado);
        barraSuperior.setAlignment(Pos.CENTER_LEFT);
        barraSuperior.setPadding(new Insets(0, 0, 12, 0));
        root.setTop(barraSuperior);

        GridPane cuadricula = new GridPane();
        cuadricula.setHgap(24);
        cuadricula.setVgap(20);
        cuadricula.setAlignment(Pos.CENTER);

        cuadricula.add(crearTableroUI(2, "Tablero 2 (Blanco)"), 0, 0);
        cuadricula.add(crearTableroUI(3, "Tablero 3 (Blanco)"), 1, 0);
        cuadricula.add(crearTableroUI(0, "Tablero 0 (Negro)"), 0, 1);
        cuadricula.add(crearTableroUI(1, "Tablero 1 (Negro)"), 1, 1);

        root.setCenter(cuadricula);
        actualizarVista();
        return root;
    }

    private VBox crearTableroUI(int idTablero, String titulo) {
        boolean esClaro = juego.esTableroClaro(idTablero);

        Label lblTitulo = new Label(titulo);
        lblTitulo.setTextFill(Color.LIGHTGRAY);
        lblTitulo.setFont(Font.font("System", FontWeight.BOLD, 12));

        GridPane grid = new GridPane();
        grid.setHgap(2);
        grid.setVgap(2);
        grid.setPadding(new Insets(6));
        grid.setStyle(esClaro
                ? "-fx-background-color: #d9b38c; -fx-border-color: #8c5a2b; -fx-border-width: 3; -fx-background-radius: 6;"
                : "-fx-background-color: #734d26; -fx-border-color: #3d2611; -fx-border-width: 3; -fx-background-radius: 6;");

        for (int f = 0; f < 4; f++) {
            for (int c = 0; c < 4; c++) {
                Shobu.Pos pos = new Shobu.Pos(idTablero, f, c);
                Button btn = new Button();
                btn.setPrefSize(56, 56);

                // LAMBDA: Evento de clic por cada casilla
                btn.setOnAction(e -> manejarClic(pos));

                botones.put(pos, btn);
                grid.add(btn, c, f);
            }
        }

        VBox box = new VBox(4, lblTitulo, grid);
        box.setAlignment(Pos.CENTER);
        return box;
    }

    private void reiniciar() {
        juego.iniciarPartida("Jugador vs Máquina".equals(cmbModo.getValue()));
        seleccionada = null;
        destinosValidos = Collections.emptyList();
        actualizarVista();
    }

    private void manejarClic(Shobu.Pos pos) {
        if (juego.obtenerGanador().isPresent() || juego.esTurnoMaquina()) return;

        if (seleccionada != null && destinosValidos.contains(pos)) {
            boolean movido = juego.ejecutarMovimiento(seleccionada, pos);
            seleccionada = null;
            destinosValidos = Collections.emptyList();
            actualizarVista();

            if (movido && juego.esTurnoMaquina()) {
                PauseTransition pausa = new PauseTransition(Duration.millis(450));
                // LAMBDA: Ejecución del turno de la IA
                pausa.setOnFinished(ev -> {
                    juego.ejecutarTurnoIA();
                    actualizarVista();
                });
                pausa.play();
            }
            return;
        }

        List<Shobu.Pos> validos = juego.obtenerDestinosValidos(pos);
        if (!validos.isEmpty()) {
            seleccionada = pos;
            destinosValidos = validos;
        } else {
            seleccionada = null;
            destinosValidos = Collections.emptyList();
        }
        actualizarVista();
    }

    private void actualizarVista() {
        // LAMBDA: Actualiza el aspecto visual de cada botón consultando Shobu
        botones.forEach((pos, btn) -> {
            String colorBase = juego.esTableroClaro(pos.tablero()) ? "#f2d9bf" : "#996633";

            if (pos.equals(seleccionada)) {
                btn.setStyle("-fx-background-color: #f1c40f; -fx-border-color: #ffffff; -fx-border-width: 2;");
            } else if (destinosValidos.contains(pos)) {
                btn.setStyle("-fx-background-color: #2ecc71; -fx-border-color: #1e8449; -fx-border-width: 2;");
            } else {
                btn.setStyle("-fx-background-color: " + colorBase + ";");
            }

            Shobu.ColorFicha ficha = juego.getFicha(pos);
            if (ficha != null) {
                Circle circulo = new Circle(18);
                circulo.setFill(ficha == Shobu.ColorFicha.NEGRO ? Color.web("#1c1c1c") : Color.web("#f8f9fa"));
                circulo.setStroke(ficha == Shobu.ColorFicha.NEGRO ? Color.GRAY : Color.DARKGRAY);
                circulo.setStrokeWidth(1.5);
                circulo.setEffect(new DropShadow(4, Color.rgb(0, 0, 0, 0.5)));
                btn.setGraphic(circulo);
            } else {
                btn.setGraphic(null);
            }
        });

        Optional<Shobu.ColorFicha> ganador = juego.obtenerGanador();
        if (ganador.isPresent()) {
            lblEstado.setText("¡GANADOR: " + ganador.get() + "!");
            lblEstado.setTextFill(Color.web("#2ecc71"));
        } else if (juego.esTurnoMaquina()) {
            lblEstado.setText("Turno: BLANCO (IA pensando...)");
            lblEstado.setTextFill(Color.web("#f1c40f"));
        } else {
            lblEstado.setText("Turno: " + juego.getTurnoActual() + " | Fase: " + juego.getFaseActual());
            lblEstado.setTextFill(Color.WHITE);
        }
    }
}