package com.example.practica5;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class Tablero {
    private final int id;
    private final boolean esClaro;
    private final Map<Shobu.Pos, Shobu.ColorFicha> fichas = new HashMap<>();

    public Tablero(int id, boolean esClaro) {
        this.id = id;
        this.esClaro = esClaro;
        reiniciar();
    }

    // Constructor de copia para que la IA simule jugadas sin modificar el tablero real
    public Tablero(Tablero otro) {
        this.id = otro.id;
        this.esClaro = otro.esClaro;
        this.fichas.putAll(otro.fichas);
    }

    public void reiniciar() {
        fichas.clear();
        for (int col = 0; col < 4; col++) {
            fichas.put(new Shobu.Pos(id, 0, col), Shobu.ColorFicha.BLANCO);
            fichas.put(new Shobu.Pos(id, 3, col), Shobu.ColorFicha.NEGRO);
        }
    }

    public boolean esPasivoValido(Shobu.Pos origen, int df, int dc, int pasos) {
        for (int p = 1; p <= pasos; p++) {
            int f = origen.fila() + df * p;
            int c = origen.col() + dc * p;
            if (!dentroLimites(f, c) || fichas.containsKey(new Shobu.Pos(id, f, c))) {
                return false;
            }
        }
        return true;
    }

    public boolean esAgresivoValido(Shobu.Pos origen, int df, int dc, int pasos, Shobu.ColorFicha turno) {
        int rivalesEnCamino = 0;

        for (int p = 1; p <= pasos; p++) {
            int f = origen.fila() + df * p;
            int c = origen.col() + dc * p;
            if (!dentroLimites(f, c)) return false;

            Shobu.ColorFicha ocupante = fichas.get(new Shobu.Pos(id, f, c));
            if (ocupante == turno) return false;
            if (ocupante != null) rivalesEnCamino++;
        }

        if (rivalesEnCamino > 1) return false;

        if (rivalesEnCamino == 1) {
            int fEmpuje = origen.fila() + df * (pasos + 1);
            int cEmpuje = origen.col() + dc * (pasos + 1);
            if (dentroLimites(fEmpuje, cEmpuje) && fichas.containsKey(new Shobu.Pos(id, fEmpuje, cEmpuje))) {
                return false;
            }
        }
        return true;
    }

    public void moverPasivo(Shobu.Pos origen, Shobu.Pos destino) {
        Shobu.ColorFicha color = fichas.remove(origen);
        fichas.put(destino, color);
    }

    public void moverAgresivo(Shobu.Pos origen, Shobu.Pos destino, int df, int dc, int pasos, Shobu.ColorFicha turno) {
        Shobu.ColorFicha rival = (turno == Shobu.ColorFicha.NEGRO) ? Shobu.ColorFicha.BLANCO : Shobu.ColorFicha.NEGRO;

        for (int p = 1; p <= pasos; p++) {
            Shobu.Pos paso = new Shobu.Pos(id, origen.fila() + df * p, origen.col() + dc * p);
            if (fichas.get(paso) == rival) {
                fichas.remove(paso);
                int fEmpuje = origen.fila() + df * (pasos + 1);
                int cEmpuje = origen.col() + dc * (pasos + 1);
                if (dentroLimites(fEmpuje, cEmpuje)) {
                    fichas.put(new Shobu.Pos(id, fEmpuje, cEmpuje), rival);
                }
                break;
            }
        }

        fichas.remove(origen);
        fichas.put(destino, turno);
    }

    public List<Shobu.Pos> obtenerPosicionesDe(Shobu.ColorFicha color) {
        // LAMBDA: Filtra las coordenadas ocupadas por un color en este tablero
        return fichas.entrySet().stream()
                .filter(e -> e.getValue() == color)
                .map(Map.Entry::getKey)
                .collect(Collectors.toList());
    }

    public long contarFichas(Shobu.ColorFicha color) {
        // LAMBDA: Cuenta las fichas restantes de un color
        return fichas.values().stream()
                .filter(c -> c == color)
                .count();
    }

    private boolean dentroLimites(int f, int c) {
        return f >= 0 && f < 4 && c >= 0 && c < 4;
    }

    public Shobu.ColorFicha getFicha(Shobu.Pos pos) { return fichas.get(pos); }
    public int getId() { return id; }
    public boolean isEsClaro() { return esClaro; }
}