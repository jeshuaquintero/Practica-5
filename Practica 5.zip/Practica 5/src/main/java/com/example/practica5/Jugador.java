package com.example.practica5;

import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.Random;
import java.util.stream.Collectors;

public class Jugador {

    public static final class Jugada {
        private final Shobu.Pos origPasivo;
        private final Shobu.Pos destPasivo;
        private final Shobu.Pos origAgresivo;
        private final Shobu.Pos destAgresivo;

        public Jugada(Shobu.Pos origPasivo, Shobu.Pos destPasivo, Shobu.Pos origAgresivo, Shobu.Pos destAgresivo) {
            this.origPasivo = origPasivo;
            this.destPasivo = destPasivo;
            this.origAgresivo = origAgresivo;
            this.destAgresivo = destAgresivo;
        }

        public Shobu.Pos origPasivo() { return origPasivo; }
        public Shobu.Pos destPasivo() { return destPasivo; }
        public Shobu.Pos origAgresivo() { return origAgresivo; }
        public Shobu.Pos destAgresivo() { return destAgresivo; }
    }

    private final Shobu.ColorFicha color;
    private final boolean esMaquina;
    private final Random random = new Random();

    public Jugador(Shobu.ColorFicha color, boolean esMaquina) {
        this.color = color;
        this.esMaquina = esMaquina;
    }

    public boolean esHomeboard(int tableroId) {
        return (color == Shobu.ColorFicha.NEGRO) ? (tableroId == 0 || tableroId == 1) : (tableroId == 2 || tableroId == 3);
    }

    public Optional<Jugada> elegirJugadaIA(Shobu juego) {
        // LAMBDA: Genera todas las combinaciones válidas (Movimiento Pasivo + Movimiento Agresivo)
        List<Jugada> jugadasPosibles = juego.getTableros().stream()
                .filter(t -> esHomeboard(t.getId()))
                .flatMap(t -> t.obtenerPosicionesDe(color).stream())
                .flatMap(origPas -> juego.obtenerDestinosValidos(origPas).stream()
                        .flatMap(destPas -> {
                            int df = Integer.signum(destPas.fila() - origPas.fila());
                            int dc = Integer.signum(destPas.col() - origPas.col());
                            int pasos = Math.max(Math.abs(destPas.fila() - origPas.fila()), Math.abs(destPas.col() - origPas.col()));
                            boolean colorTableroPasivo = juego.esTableroClaro(origPas.tablero());

                            return juego.getTableros().stream()
                                    .filter(tAgr -> tAgr.isEsClaro() != colorTableroPasivo)
                                    .flatMap(tAgr -> tAgr.obtenerPosicionesDe(color).stream()
                                            .filter(origAgr -> tAgr.esAgresivoValido(origAgr, df, dc, pasos, color))
                                            .map(origAgr -> new Jugada(
                                                    origPas,
                                                    destPas,
                                                    origAgr,
                                                    new Shobu.Pos(origAgr.tablero(), origAgr.fila() + df * pasos, origAgr.col() + dc * pasos)
                                            )));
                        }))
                .collect(Collectors.toList());

        // LAMBDA: Selecciona la mejor jugada evaluando una heurística con Comparator
        return jugadasPosibles.stream()
                .max(Comparator.comparingInt(jugada -> evaluarJugada(juego, jugada)));
    }

    private int evaluarJugada(Shobu estadoActual, Jugada j) {
        Shobu sim = new Shobu(estadoActual);
        Shobu.ColorFicha rival = (color == Shobu.ColorFicha.NEGRO) ? Shobu.ColorFicha.BLANCO : Shobu.ColorFicha.NEGRO;

        long rivalesAntes = sim.contarFichasTotales(rival);
        sim.ejecutarMovimiento(j.origPasivo(), j.destPasivo());
        sim.ejecutarMovimiento(j.origAgresivo(), j.destAgresivo());

        if (sim.obtenerGanador().orElse(null) == color) return 10_000;

        long rivalesDespues = sim.contarFichasTotales(rival);
        int puntos = (int) ((rivalesAntes - rivalesDespues) * 400);

        if (sim.getTableros().stream().anyMatch(t -> t.contarFichas(rival) == 1)) puntos += 200;
        if (sim.getTableros().stream().anyMatch(t -> t.contarFichas(color) == 1)) puntos -= 250;

        int f = j.destAgresivo().fila();
        int c = j.destAgresivo().col();
        if ((f == 1 || f == 2) && (c == 1 || c == 2)) puntos += 25;

        return puntos + random.nextInt(15);
    }

    public Shobu.ColorFicha getColor() { return color; }
    public boolean isEsMaquina() { return esMaquina; }
}