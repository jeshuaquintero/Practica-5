package com.example.practica5;

import java.util.ArrayList;
import java.util.Collections;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

public class Shobu {

    public enum ColorFicha { NEGRO, BLANCO }
    public enum Fase { PASIVO, AGRESIVO }

    public static final class Pos {
        private final int tablero;
        private final int fila;
        private final int col;

        public Pos(int tablero, int fila, int col) {
            this.tablero = tablero;
            this.fila = fila;
            this.col = col;
        }

        public int tablero() { return tablero; }
        public int fila() { return fila; }
        public int col() { return col; }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (!(o instanceof Pos)) return false;
            Pos pos = (Pos) o;
            return tablero == pos.tablero && fila == pos.fila && col == pos.col;
        }

        @Override
        public int hashCode() {
            return Objects.hash(tablero, fila, col);
        }
    }

    private final List<Tablero> tableros = new ArrayList<>();
    private final Map<ColorFicha, Jugador> jugadores = new EnumMap<>(ColorFicha.class);

    private ColorFicha turnoActual;
    private Fase faseActual;
    private int tableroPasivoId;
    private int dfPasivo;
    private int dcPasivo;
    private int pasosPasivo;

    public Shobu() {
        iniciarPartida(false);
    }

    // Constructor de copia para simulaciones de la IA
    public Shobu(Shobu otro) {
        // LAMBDA: Clona la lista de tableros
        otro.tableros.forEach(t -> this.tableros.add(new Tablero(t)));
        this.jugadores.putAll(otro.jugadores);
        this.turnoActual = otro.turnoActual;
        this.faseActual = otro.faseActual;
        this.tableroPasivoId = otro.tableroPasivoId;
        this.dfPasivo = otro.dfPasivo;
        this.dcPasivo = otro.dcPasivo;
        this.pasosPasivo = otro.pasosPasivo;
    }

    public void iniciarPartida(boolean vsMaquina) {
        tableros.clear();
        // Tablero 0 (Oscuro) y 1 (Claro) -> Homeboards NEGRO
        // Tablero 2 (Claro) y 3 (Oscuro)  -> Homeboards BLANCO
        tableros.add(new Tablero(0, false));
        tableros.add(new Tablero(1, true));
        tableros.add(new Tablero(2, true));
        tableros.add(new Tablero(3, false));

        jugadores.put(ColorFicha.NEGRO, new Jugador(ColorFicha.NEGRO, false));
        jugadores.put(ColorFicha.BLANCO, new Jugador(ColorFicha.BLANCO, vsMaquina));

        turnoActual = ColorFicha.NEGRO;
        faseActual = Fase.PASIVO;
        tableroPasivoId = -1;
    }

    public List<Pos> obtenerDestinosValidos(Pos origen) {
        if (obtenerGanador().isPresent()) return Collections.emptyList();

        Tablero tablero = tableros.get(origen.tablero());
        if (tablero.getFicha(origen) != turnoActual) return Collections.emptyList();

        Jugador jugador = jugadores.get(turnoActual);

        if (faseActual == Fase.PASIVO) {
            if (!jugador.esHomeboard(origen.tablero())) return Collections.emptyList();

            // LAMBDA: Filtra direcciones válidas para el movimiento pasivo y calcula los destinos
            return generarDirecciones().stream()
                    .filter(d -> tablero.esPasivoValido(origen, d[0], d[1], d[2]))
                    .filter(d -> existeAlMenosUnAgresivo(origen.tablero(), d[0], d[1], d[2]))
                    .map(d -> new Pos(origen.tablero(), origen.fila() + d[0] * d[2], origen.col() + d[1] * d[2]))
                    .collect(Collectors.toList());
        } else {
            boolean colorPasivo = tableros.get(tableroPasivoId).isEsClaro();
            if (tablero.isEsClaro() == colorPasivo) return Collections.emptyList();

            if (tablero.esAgresivoValido(origen, dfPasivo, dcPasivo, pasosPasivo, turnoActual)) {
                return Collections.singletonList(
                        new Pos(origen.tablero(), origen.fila() + dfPasivo * pasosPasivo, origen.col() + dcPasivo * pasosPasivo)
                );
            }
            return Collections.emptyList();
        }
    }

    public boolean ejecutarMovimiento(Pos origen, Pos destino) {
        if (!obtenerDestinosValidos(origen).contains(destino)) return false;

        Tablero tablero = tableros.get(origen.tablero());
        int df = Integer.signum(destino.fila() - origen.fila());
        int dc = Integer.signum(destino.col() - origen.col());
        int pasos = Math.max(Math.abs(destino.fila() - origen.fila()), Math.abs(destino.col() - origen.col()));

        if (faseActual == Fase.PASIVO) {
            tablero.moverPasivo(origen, destino);
            tableroPasivoId = origen.tablero();
            dfPasivo = df;
            dcPasivo = dc;
            pasosPasivo = pasos;
            faseActual = Fase.AGRESIVO;
        } else {
            tablero.moverAgresivo(origen, destino, df, dc, pasos, turnoActual);
            turnoActual = (turnoActual == ColorFicha.NEGRO) ? ColorFicha.BLANCO : ColorFicha.NEGRO;
            faseActual = Fase.PASIVO;
            tableroPasivoId = -1;
        }
        return true;
    }

    public boolean ejecutarTurnoIA() {
        if (!esTurnoMaquina() || obtenerGanador().isPresent()) return false;

        Optional<Jugador.Jugada> jugada = jugadores.get(turnoActual).elegirJugadaIA(this);
        if (jugada.isPresent()) {
            Jugador.Jugada j = jugada.get();
            ejecutarMovimiento(j.origPasivo(), j.destPasivo());
            ejecutarMovimiento(j.origAgresivo(), j.destAgresivo());
            return true;
        }
        return false;
    }

    public Optional<ColorFicha> obtenerGanador() {
        // LAMBDA: Verifica si algún tablero se quedó sin fichas de un color
        if (tableros.stream().anyMatch(t -> t.contarFichas(ColorFicha.NEGRO) == 0)) {
            return Optional.of(ColorFicha.BLANCO);
        }
        if (tableros.stream().anyMatch(t -> t.contarFichas(ColorFicha.BLANCO) == 0)) {
            return Optional.of(ColorFicha.NEGRO);
        }
        return Optional.empty();
    }

    public long contarFichasTotales(ColorFicha color) {
        return tableros.stream().mapToLong(t -> t.contarFichas(color)).sum();
    }

    private boolean existeAlMenosUnAgresivo(int idTableroPasivo, int df, int dc, int pasos) {
        boolean colorPasivo = tableros.get(idTableroPasivo).isEsClaro();
        // LAMBDA: Comprueba con anyMatch que el movimiento pasivo tenga al menos un agresivo posible
        return tableros.stream()
                .filter(t -> t.isEsClaro() != colorPasivo)
                .anyMatch(t -> t.obtenerPosicionesDe(turnoActual).stream()
                        .anyMatch(pos -> t.esAgresivoValido(pos, df, dc, pasos, turnoActual)));
    }

    private List<int[]> generarDirecciones() {
        List<int[]> dirs = new ArrayList<>();
        for (int df = -1; df <= 1; df++) {
            for (int dc = -1; dc <= 1; dc++) {
                if (df == 0 && dc == 0) continue;
                dirs.add(new int[]{df, dc, 1});
                dirs.add(new int[]{df, dc, 2});
            }
        }
        return dirs;
    }

    public ColorFicha getFicha(Pos pos) { return tableros.get(pos.tablero()).getFicha(pos); }
    public boolean esTableroClaro(int id) { return tableros.get(id).isEsClaro(); }
    public boolean esTurnoMaquina() { return jugadores.get(turnoActual).isEsMaquina(); }
    public ColorFicha getTurnoActual() { return turnoActual; }
    public Fase getFaseActual() { return faseActual; }
    public List<Tablero> getTableros() { return Collections.unmodifiableList(tableros); }
}