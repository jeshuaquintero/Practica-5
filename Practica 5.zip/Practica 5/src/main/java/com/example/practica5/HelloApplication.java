package com.example.practica5;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class HelloApplication extends Application {
    @Override
    public void start(Stage stage) {
        HelloController controller = new HelloController();
        Scene scene = new Scene(controller.crearInterfaz(), 660, 710);
        stage.setTitle("Shobu - Programación Orientada a Objetos");
        stage.setScene(scene);
        stage.setResizable(false);
        stage.show();
    }
}